# if the venv already exists do nothing
if [ -d "./wolf_inns_venv" ]; then
    source wolf_inns_venv/bin/activate
# else create it and install requirements
else
    virtualenv wolf_inns_venv
    source wolf_inns_venv/bin/activate
    pip install -r requirements.txt
fi
