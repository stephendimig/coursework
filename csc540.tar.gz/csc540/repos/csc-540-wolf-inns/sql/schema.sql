CREATE TABLE Staff (
	EmployeeID int Auto_Increment PRIMARY KEY,
	Age int NOT NULL,
	JobTitle Enum('MANAGER', 'FRONT_DESK', 'REPRESENTATIVE', 'ROOM_SERVICE', 'BILLING_STAFF', 'CATERING') NOT NULL,
    Department int NOT NULL    
    );

CREATE TABLE Hotel (
	ID int auto_increment primary key,
	ManagerID int,
    foreign key (ManagerID) References Staff(EmployeeID) On Update cascade On Delete SET NULL
    );

CREATE TABLE Room (
	Number int,
	HotelID int references Hotel(ID) on delete SET NULL ON update cascade,	
	Category Enum('ECONOMY', 'DELUXE', 'EXECUTIVE_SUITE', 'PRESEDENTIAL_SUITE') NOT NULL,
    Occupancy int NOT NULL,
    Rate decimal(9, 2) NOT NULL,    
    Availability tinyint(1) NOT NULL,
    primary key (Number, HotelID)
    );

CREATE TABLE Contact_Info (
	ID int Auto_Increment PRIMARY KEY,
	`Name` varchar(100) NOT NULL,	
    Address varchar(100) NOT NULL,
    City varchar(60) NOT NULL,
    State varchar(50) NOT NULL,
    Zip varchar(10) NOT NULL,
    Phone_Number varchar(12),	
    Email varchar(100)
    );
    
CREATE TABLE Service (
	ID int Auto_Increment PRIMARY KEY,
	Cost decimal(9, 2) Not Null,
	`Name` varchar(100),
	`Desc` varchar(100)	
);

CREATE TABLE Check_In (
	ID int Auto_Increment PRIMARY KEY,
        Num_Guests int NOT NULL,
	Hotel_ID int NOT NULL,
	Room_Number int NOT NULL,
        Loyalty_Number int NOT NULL,
        Check_in_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        Check_out_time TIMESTAMP NULL,
        Duration int DEFAULT NULL,
	CostServices decimal(9,2) DEFAULT NULL,
	CostOfRoom decimal(9,2) DEFAULT NULL,
	Discount decimal(9,2) DEFAULT NULL,
	TotalCost decimal(9,2) DEFAULT NULL,
	foreign key(Hotel_ID) references Hotel(ID) on update cascade    
);

CREATE TABLE Service_Log (
	LogID int Auto_Increment,
	EmployeeID int,
	`TimeStamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ServiceID int,
    Check_In_ID int,
    primary key (LogID, EmployeeID, ServiceID, Check_In_ID),
	foreign key(EmployeeID) references Staff(EmployeeID) on update cascade,
	foreign key(ServiceID) references Service(ID) on update cascade,
	foreign key(Check_In_ID) references Check_In(ID) on update cascade
);

CREATE TABLE Customer (	
	ID int Auto_Increment primary Key,
    DOB date NOT Null
);

CREATE TABLE BillingInfo (
	ID int Auto_Increment,
	Customer_Loyalty_Number int,
	PaymentMethod Enum('CASH', 'CREDIT', 'HOTEL_CREDIT', 'DEBIT', 'CHECK') Not Null,
    BillingAddress varchar(100) Not Null,
    CreditCardNumber varchar(16),
    primary key (ID, Customer_Loyalty_Number),
	foreign key(Customer_Loyalty_Number) references Customer(ID) on update cascade
);

CREATE TABLE Serves_At (	
	EmployeeID int,
    HotelID int,
    primary key (EmployeeID, HotelID),
	foreign key(EmployeeID) references Staff(EmployeeID) on update cascade,
	foreign key(HotelID) references Hotel(ID) ON update cascade
);

CREATE TABLE Emp_Contact_Info (	
	EmployeeID int,
    Contact_Info_ID int,
    primary key (EmployeeID, Contact_Info_ID),
	foreign key(EmployeeID) references Staff(EmployeeID) on update cascade,
	foreign key(Contact_Info_ID) references Contact_Info(ID) ON update cascade
);

CREATE TABLE Hotel_Contact_Info (	
	Hotel_ID int,
    Contact_Info_ID int,
    primary key (Hotel_ID, Contact_Info_ID),
	foreign key(Hotel_ID) references Hotel(ID) ON update cascade,
	foreign key(Contact_Info_ID) references Contact_Info(ID) ON update cascade
);

CREATE TABLE Customer_Contact_Info (	
	Customer_Loyalty_Number int,
    Contact_Info_ID int,
    primary key (Customer_Loyalty_Number, Contact_Info_ID),
	foreign key(Customer_Loyalty_Number) references Customer(ID) ON update cascade,
	foreign key(Contact_Info_ID) references Contact_Info(ID) ON update cascade
);

CREATE TABLE Has_Services (	
	Hotel_ID int,
    ServiceID int,
    primary key (Hotel_ID, ServiceID),
	foreign key(Hotel_ID) references Hotel(ID) ON update cascade,
	foreign key(ServiceID) references Service(ID) on update cascade
);

CREATE TABLE Service_Instance (	
	Service_Log int,
	EmployeeID int,
    ServiceID int,
    primary key (Service_Log, EmployeeID, ServiceID),
	foreign key(ServiceID) references Service(ID) on update cascade,
	foreign key(EmployeeID) references Staff(EmployeeID) on update cascade,
	foreign key(Service_Log) references Service_Log(LogID) ON update cascade
);

CREATE TABLE Used_Services (
	ServiceID int references Service(ID) on update cascade,
	Hotel_ID int references Hotel(ID) ON update cascade,
	Room_Number int NOT NULL,
	Loyalty_Number int NOT NULL,
	Log_ID int NOT NULL,    
    primary key (ServiceID, Hotel_ID, Room_Number, Loyalty_Number, Log_ID),
	foreign key(ServiceID) references Service(ID) on update cascade,
	foreign key(Hotel_ID) references Hotel(ID) ON update cascade,
	foreign key(Room_Number) references Room(Number) ON update cascade,
	foreign key(Loyalty_Number) references Customer(ID) ON update cascade,
	foreign key(Log_ID) references Service_Log(LogID) ON update cascade
);

CREATE TABLE Check_In_To (
	Check_In_ID int,	
	Room_Number int,
	Hotel_ID int,
	Loyalty_Number int,
	
    primary key (Check_In_ID, Hotel_ID, Room_Number, Loyalty_Number),	
	foreign key(Hotel_ID) references Hotel(ID) ON update cascade,
	foreign key(Room_Number) references Room(Number) ON update cascade,
	foreign key(Loyalty_Number) references Customer(ID) ON update cascade	
);

#****************** Start Seeding ****************************************************
INSERT INTO Staff (Age, JobTitle, Department)
VALUES (32, 'MANAGER', 1),
(28, 'BILLING_STAFF', 3),
(20, 'FRONT_DESK', 3),
(23, 'ROOM_SERVICE', 3),
(45, 'CATERING', 5),
(45, 'REPRESENTATIVE', 6),
(41, 'MANAGER', 4),
(34, 'REPRESENTATIVE', 5),
(36, 'MANAGER', 2),
(33, 'MANAGER', 3),
(45, 'CATERING', 2),
(23, 'REPRESENTATIVE', 2),
(21, 'CATERING', 2),
(56, 'MANAGER', 5),
(25, 'MANAGER', 6),
(28, 'ROOM_SERVICE', 2),
(20, 'FRONT_DESK', 3);


INSERT INTO Hotel (ManagerID)
VALUES (1),
(7),
(9),
(10),
(14),
(15);

INSERT INTO Room (Number, HotelID, Category, Occupancy, Rate, Availability)
VALUES (100, 1, 'PRESEDENTIAL_SUITE', 2, 299.99, 1),
(232, 2, 'PRESEDENTIAL_SUITE', 2, 299.99, 0),
(147, 3, 'DELUXE', 4, 149.99, 1),
(320, 4, 'ECONOMY', 4, 99.99, 0),
(263, 5, 'EXECUTIVE_SUITE', 4, 399.99, 1),
(110, 6, 'ECONOMY', 4, 69.99, 0);


INSERT INTO Contact_Info(`Name`, Address, City, State, Zip, Phone_Number, Email)
VALUES ('Carmen K House', '347 Nancy Street', 'Cary', 'North Carolina', '27513', '919-625-4982', 'mthurn@live.com'),
('Alexandra T Hoffman', '3051 Lowes Alley', 'Steubenville', 'Ohio', '43952', '740-283-5087', 'rgarcia@optonline.net'),
('Frances W Gillis', '4931 Abia Martin Drive', 'Farmingdale', 'New York', '11735', '631-577-6005', 'crandall@sbcglobal.net'),
('George J Driggers', '2058 Wescam Court', 'Reno', 'Nevada', '89501', '775-908-2750', 'fangorn@hotmail.com'),
('Danielle D Graves', '3021 Williams Lane', 'HANSON', 'Kentucky', '42413', '316-453-9331', 'mxiao@yahoo.com'),
('Donald C Moulton', '3075 Randolph Street', 'North Attleboro', 'Massachusetts', '02760', '508-695-9651', 'jguyer@aol.com'),
('Amy J Brown', '1140 Evergreen Lane', 'Los Angeles', 'California', '90036', '323-549-8835', 'drezet@me.com'),
('Sheila W Lee', '1429 Pritchard Court', 'Cottonwood', 'Minnesota', '56229', '507-423-2579', 'euice@outlook.com'),
('Light Square', '1165 Liberty Avenue', 'Anaheim', 'California', '92805', '714-465-3914', 'Light.Square@Hotel.com'),
('Crimson Panorama', '3494 Tator Patch Road', 'Chicago', 'Illinois', '60606', '312-905-0304', 'Crimson.Panorama@Hotel.com'),
('Silver Vale', '1318 Twin House Lane', 'Jasper', 'Missouri', '64755', '417-394-5408', 'Silver.Vale@Hotel.com'),
('Jade Fjord', '3661 Flanigan Oaks Drive', 'Capitol Heights', 'Maryland', '20027', '301-333-5571', 'Jade.Fjord@Hotel.com'),
('Northern River', '1340 Barnes Street', 'Orlando', 'Florida', '32808', '407-290-4833', 'Northern.River@Hotel.com'),
('Elegant', '1863 Morningview Lane', 'New York', 'New York', '10011', '646-230-3578', 'Elegant@hotel.com'),
('Virginia Bowman', '15819 Rachelle Manor', 'West Rhiannamouth', 'New Hampshire', '65778', '824-601-8147', 'Virginia.Brown@gmail.com'),
('Laura Knight', '14516 Rachelle Manor', 'West Rhiannamouth', 'New Hampshire', '65778', '824-569-8740', 'Maybelle@maya.com'),
('Alan Gill', '157 Vida Passage', 'West Sylviaview', 'Pennsylvania', '87533-9082', '343-113-7203', 'Marques@martina.info'),
('Guadalupe Greer', '8722 Odessa Circle', 'North Fredymouth', 'Tennessee', '93805', '316-941-0710', 'Mafalda@carmine.tv'),
('Erik Burgess', '618 Macey Course', 'Elodyhaven', 'Arkansas', '91427-9437', '816-689-0754', 'Blaze_Purdy@tyrell.tv'),
('Helen Mckenzie', '72829 Leann Road', 'Lake Lonniechester', 'Pennsylvania', '89616', '808-598-3083', 'Ramona.Leannon@madie.net'),
('Carmen Schultz', '80622 Nikolaus Parks', 'West Kavon', 'Connecticut', '44434-0711', '305-482-0722', 'Dayton.Effertz@alvera.ca'),
('Caroline Rogers', '94535 Ellsworth Vista', 'Carleyland', 'Michigan', '17340-2256', '106-664-9173', 'Pedro.Denesik@gabe.net'),
('Flora Holland', '2911 Carlotta Lights', 'Legrosberg', 'Kentucky', '78980', '914-874-7451', 'Obie@elva.biz'),
('Jack Harris', '255 Freddy Fall', 'West Elinoretown', 'Georgia', '07167-8923', '570-959-2541', 'Florida@kara.tv'),
('Juan Diaz', '59958 Rico Course', 'Ortizside', 'Nevada', '67670', '384-801-4374', 'Annabell.Toy@sylvester.me'),
('Samuel Simmons', '361 Tillman Row', 'Adelbertstad', 'Hawaii', '38501', '724-523-3613', 'Santina.Bailey@jayne.info'),
('Michael Robinson', '59382 Schaefer Station', 'Jamalfort', 'Missouri', '84301', '365-305-4659', 'Dena@makayla.ca'),
('Albert Gray', '5226 Jazmin Extensions', 'West Kobe', 'Delaware', '10304-8784', '894-543-3038', 'Tatyana_Schaefer@craig.info'),
('Susan Howard', '44328 Aletha Glen', 'South Emmett', 'California', '16676', '505-783-6447', 'Kenna@chelsey.tv'),
('Paul Morris', '762 Calista Mount', 'Berylville', 'West Virginia', '70094-5984', '782-471-0731', 'Katrina_Dooley@toni.biz'),
('Patrick Miller', '072 Jamil Key', 'Dariusside', 'Ohio', '72177', '154-717-7246', 'Marcelina.Deckow@roscoe.co.uk');


INSERT INTO Service (Cost, `Name`, `Desc`)
VALUES (5.99, 'Dry Cleaning', 'This is the cost per item'),
(15.00, 'Room Service', 'Fee for room service in addition to the cost of the items.'),
(49.99, 'Yogo Instruction', 'Cost for Yogo instructor per hour'),
(19.99, 'Pet Sitting', 'Cost for caring for each pet each day.'),
(3.99, 'Package Receiving', 'Cost to receive packages, per day, from couriers at front desk.'),
(29.99, 'Valet Service', 'Cost for Valet service per day.');

INSERT INTO Check_In (Num_Guests, Hotel_ID, Room_Number, Loyalty_Number, Check_in_time, Check_out_time, Duration, CostServices, CostOfRoom, Discount, TotalCost)
VALUES (2, 1, 100, 1, '2018-03-15 18:54:05', '2018-03-18 18:54:05', 3, 70.98, 899.97, 0.00, 970.95),
(2, 2, 232, 3, '2018-03-15 18:54:05', NULL, NULL, NULL, NULL, NULL, NULL),
(2, 3, 147, 2, '2018-03-15 18:54:05', '2018-03-18 18:54:05', 3, 19.99, 449.97, 0.00, 469.96),
(2, 4, 320, 4, '2018-03-15 18:54:05', NULL, NULL, NULL, NULL, NULL, NULL),
(2, 5, 263, 5, '2018-03-15 18:54:05', '2018-03-18 18:54:05', 3, 0.00, 1199.97, 0.00, 1199.97),
(2, 6, 110, 6, '2018-03-15 18:54:05', NULL, NULL, NULL, NULL, NULL, NULL);


INSERT INTO Service_Log (EmployeeID, ServiceID, Check_In_ID, TimeStamp)
VALUES (1, 2, 1,  '2018-03-18 18:54:05'),
(3, 3, 1,  '2018-03-18 18:54:05'),
(6, 1, 1,  '2018-03-18 18:54:05'),
(2, 4, 3,  '2018-03-18 18:54:05'),
(3, 5, 4,  '2018-03-18 18:54:05'),
(5, 1, 4,  '2018-03-18 18:54:05');

INSERT INTO Customer (DOB)
VALUES ('1979-9-14' ),
('1960-6-6'),
('1959-5-30'),
('1989-8-7'),
('1994-4-25'),
('1998-7-26'),
('1968-6-27'),
('1989-9-29');

INSERT INTO Serves_At(EmployeeID, HotelID)
VALUES (1, 1),
(2, 1),
(3, 2),
(3, 3),
(4, 3),
(5, 2),
(6, 5);

INSERT INTO Emp_Contact_Info(EmployeeID, Contact_Info_ID)
VALUES (1, 15),
(2, 16),
(3, 17),
(4, 18),
(5, 19),
(6, 20),
(7, 21),
(8, 22),
(9, 23),
(10, 24),
(11, 25),
(12, 26),
(13, 27),
(14, 28),
(15, 29),
(16, 30),
(17, 31);

INSERT INTO Hotel_Contact_Info(Hotel_ID, Contact_Info_ID)
VALUES (1, 9),
(2, 10),
(3, 11),
(4, 12),
(5, 13),
(6, 14);


INSERT INTO Customer_Contact_Info(Customer_Loyalty_Number, Contact_Info_ID)
VALUES (1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8);

INSERT INTO Has_Services(Hotel_ID, ServiceID)
VALUES (1, 1),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(2, 2),
(2, 4),
(2, 5),
(2, 6),
(3, 1),
(3, 2),
(3, 3),
(3, 5),
(3, 6),
(4, 1),
(4, 3),
(4, 4),
(4, 5),
(4, 6),
(5, 1),
(5, 3),
(5, 4),
(5, 5),
(6, 1),
(6, 2),
(6, 4),
(6, 6);


INSERT INTO Service_Instance(Service_Log, EmployeeID, ServiceID)
VALUES (1, 1, 2),
(2, 3, 3),
(3, 6, 1),
(4, 2, 4),
(5, 3, 5),
(6, 5, 1);


INSERT INTO Used_Services (ServiceID, Hotel_ID, Room_Number, Loyalty_Number, Log_ID)
VALUES (2, 1, 100, 6, 1),
(3, 2, 232, 3, 2),
(1, 3, 147, 1, 3),
(4, 4, 320, 4, 4),
(5, 5, 263, 5, 5),
(1, 6, 110, 2, 6);

INSERT INTO Check_In_To (Check_In_ID, Room_Number, Hotel_ID, Loyalty_Number)
VALUES (1, 100, 1, 1),
(2, 232, 2, 3),
(3, 147, 3, 2),
(4, 320, 4, 4),
(5, 263, 5, 5),
(6, 110, 6, 6);

