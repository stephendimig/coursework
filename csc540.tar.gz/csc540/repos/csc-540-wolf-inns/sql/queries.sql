# Create, update, and delete information about a hotel
SELECT * FROM Hotel;
#	Create a new hotel, with an existing manager
INSERT INTO Hotel( ManagerID)
VALUES (14);

SELECT last_insert_id(); # Note Hotel ID, it was 8

INSERT INTO Contact_Info(`Name`, Address, City, State, Zip, Phone_Number, Email)
VALUES ('My Hotel', '12345 St', 'Cary', 'North Carolina', '27513', '919-625-4982', 'hotel@hotels.com');

SELECT last_insert_id(); # Note Contact ID, it was 33

INSERT INTO Hotel_Contact_Info(Hotel_ID, Contact_Info_ID)
VALUES (8, 32);


#	Update the name or manager of a hotel, given a hotel ID
UPDATE Contact_Info
SET Name ="The Wolf Ritz"
WHERE Contact_Info.ID="32";

UPDATE Hotel
SET Hotel.ManagerID ="14"
WHERE Hotel.ID="7";

# Delete a hotel given a hotel ID
DELETE FROM Hotel_Contact_Info
WHERE Hotel_ID="7";

DELETE FROM Hotel
WHERE Hotel.ID="7";

DELETE FROM Contact_Info
WHERE Contact_Info.ID="32";


# Create, update, and delete information about a room
# 	Add a room to a Hotel
INSERT INTO Room(Number, HotelID, Category, Occupancy, Rate, Availability)
VALUES (101, 8, "DELUXE", 4, 149.99, 0);

# Update the category of a room
UPDATE Room
SET Room.Category="ECONOMY"
WHERE Room.Number=101 and Room.HotelID=8;

# Delete a room from a hotel
DELETE FROM Room
WHERE Room.Number=101 and Room.HotelID=8;

# Create, update, and delete information about an employee
# Add a new employee
INSERT INTO Staff (Age, JobTitle, Department)
VALUES (27, 'CATERING', 5);

SELECT last_insert_id(); # Note Staff ID, it was 18

INSERT INTO Contact_Info(`Name`, Address, City, State, Zip, Phone_Number, Email)
VALUES ('Rock Johnson', '347 Nancy Street', 'Cary', 'North Carolina', '27513', '919-625-4982', 'mthurn@live.com');

SELECT last_insert_id(); # Note Contact ID, it was 34

INSERT INTO Emp_Contact_Info(EmployeeID, Contact_Info_ID)
VALUES (18, 34);

# Change the Dept and Title of an employee
UPDATE Staff SET 
	Staff.JobTitle="ROOM_SERVICE",
    Staff.Department=2
WHERE Staff.EmployeeID=18;

# Delete an employee
DELETE FROM Emp_Contact_Info
WHERE EmployeeID = 18;

DELETE FROM Contact_Info
WHERE ID = 34;

DELETE FROM Staff
WHERE Staff.EmployeeID=18;

# Create, update, and delete information about a customer
# Create a new Customer
INSERT INTO Customer (DOB)
VALUES ('1969-9-14' );

SELECT last_insert_id(); # Note Staff ID, it was 9

INSERT INTO Contact_Info(`Name`, Address, City, State, Zip, Phone_Number, Email)
VALUES ('Ron Swanson', '347 Nancy Street', 'Cary', 'North Carolina', '27513', '919-625-4982', 'mthurn@live.com');

SELECT last_insert_id(); # Note Contact ID, it was 35

INSERT INTO Customer_Contact_Info(Customer_Loyalty_Number, Contact_Info_ID)
VALUES (9, 36);

# Update a customer's name
UPDATE Contact_Info SET
	Contact_Info.Name = "Rick Lester"
WHERE ID=35;

# Delete a Customer
DELETE FROM Customer_Contact_Info
WHERE Customer_Loyalty_Number = 9;

DELETE FROM Contact_Info
WHERE ID = 35;

DELETE FROM Customer
WHERE Customer.ID=9;

# Check for availability of a room and room type for a hotel
SELECT Contact_Info.Name, Room.Number as Room_Num, Room.Rate FROM
	Hotel 
		JOIN Room 
			on Hotel.ID = Room.HotelID
		JOIN Hotel_Contact_Info
			on Hotel.ID = Hotel_Contact_Info.Hotel_ID
		JOIN Contact_Info
			on Hotel_Contact_Info.Contact_Info_ID = Contact_Info.ID
WHERE 
	Room.Availability=1 AND
    Room.Category="DELUXE";
    
# Check a customer in
SELECT * FROM Check_In;

INSERT INTO Check_In (Num_Guests, Hotel_ID, Room_Number, Loyalty_Number, Check_in_time, check_out_time)
VALUES (2, 3, 147, 3, current_timestamp());

# Check a customer out
UPDATE Check_In SET
	Check_In.Check_out_time = date_add(current_timestamp(), interval 3 Day)
WHERE Check_In.Hotel_ID = 3 and 
	Check_In.Room_Number = 147 and 
	Check_In.Loyalty_Number = 3;
    
    
## Maintain Service Records
# Add a service record for a customer's stay
# Employee enters the log of them performing a service
INSERT INTO Service_Log(EmployeeID, `TimeStamp`, ServiceID)
VALUES (3, current_timestamp(),3);

# and then attributes that new service to a customer
INSERT INTO Used_Services(ServiceID, Hotel_ID, Room_Number, Loyalty_Number, Log_ID)
VALUES (2, 1, 100, 6, 7);



    

