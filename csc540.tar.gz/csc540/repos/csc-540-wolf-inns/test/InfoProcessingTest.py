##########################################################
##
## File: InfoProcessingTest.py
## Author:
## Description: This file contains the test driver for the InfoProcessing
## class
##
## This InfoProcessing class roughly corresponds to the InfoProcessing API described
## in the Project Report 1, with some further enahancements from the InfoProcessing section in
## the Interactive SQL queries section from Project Report 2. It has all of the queries
## described there in a class with appropriate error checks and tests.
##
##########################################################

import unittest
import os
from InfoProcessing import InfoProcessing
from Properties import Properties
import Utils
from tabulate import tabulate

##
## Class: InfoProcessingTest
## Description: The test driver for the InfoProcessing
##
class InfoProcessingTest(unittest.TestCase):
    ##
    ## Name: setUp
    ## Description:  The setUp fixture for the InfoProcessingTest class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def setUp(self):
        propertiesFile = os.environ.get('PROPERTIES_FILE')
        Properties.Instance().loadFile(propertiesFile)
        Utils.setUpLogging()
        self.infoProcessing = InfoProcessing()

    ##
    ## Name: testCustomerContactInfo
    ## Description:  Tests the Customer Contact related methods on the InfoProcessing class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def testCustomerContactInfo(self):
        self.assertEquals(self.infoProcessing.__getContactInfoId__(7), 7)
        df = self.infoProcessing.getCustomerContact(7)
        self.assertEquals(df['Name'][0], 'Amy J Brown')
        self.assertEquals(df['Address'][0], '1140 Evergreen Lane')
        self.assertEquals(df['City'][0], 'Los Angeles')
        self.assertEquals(df['State'][0], 'California')
        self.assertEquals(df['Zip'][0], '90036')
        self.assertEquals(df['Phone_Number'][0], '323-549-8835')

        loyaltyNumber = 8
        self.infoProcessing.deleteCustomerContact(loyaltyNumber)
        df = self.infoProcessing.getCustomerContact(loyaltyNumber)
        self.assertTrue(len(df.index) == 0)

        name = 'Sheila W Lee'
        address = '1429 Pritchard Court'
        city = 'Cottonwood'
        state = 'Minnesota'
        zip = '56229'
        phone = '507-423-2579'
        email = '123abc@hc.rr.com'
        self.infoProcessing.createCustomerContact(loyaltyNumber, name, address, city, state, zip, phone, email)
        df = self.infoProcessing.getAllCustomerContact()
        mydf = df[df.Name==name]
        self.assertTrue(len(mydf.index) > 0)


        email2 = 'euice@outlook.com'
        self.infoProcessing.updateCustomerContact(loyaltyNumber, email=email2)
        df = self.infoProcessing.getAllCustomerContact()
        mydf = df[df.Email == email2]
        self.assertTrue(len(mydf.index) > 0)
        mydf = df[df.Email == email]
        self.assertTrue(len(mydf.index) == 0)


if __name__ == '__main__':
    unittest.main()
