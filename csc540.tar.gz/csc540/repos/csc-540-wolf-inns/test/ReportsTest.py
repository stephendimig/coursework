##########################################################
##
## File: ReportsTest.py
## Author: Stephen Dimig (smdimig@ncsu.edu)
## Description: This file contains the test driver for the Reports
## class
##
## The Reports class roughly corresponds to the Reports API described
## in the Project Report 1, with some further enahancements from the Reports section in
## the Interactive SQL queries section from Project Report 2. It has all of the queries
## described there in a class with appropriate error checks and tests.
##
##########################################################

import unittest
import os
from Reports import Reports
from Properties import Properties
import Utils
from tabulate import tabulate

##
## Class: ReportsTest
## Description: The test driver for the Reports
##
class ReportsTest(unittest.TestCase):
    ##
    ## Name: setUp
    ## Description:  The setUp fixture for the ReportsTest class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def setUp(self):
        propertiesFile = os.environ.get('PROPERTIES_FILE')
        Properties.Instance().loadFile(propertiesFile)
        Utils.setUpLogging()
        self.reports = Reports()

    ##
    ## Name: testReportOccupancyByHotel
    ## Description:  Tests reportOccupancyByHotel method on the Reports class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def testReportOccupancyByHotel(self):
        df = self.reports.reportOccupancyByHotel()
        self.assertEqual(len(df.index), 3)
        self.assertEqual(df['Hotel Name'][0], 'Crimson Panorama')
        self.assertEqual(df['Hotel Name'][1], 'Elegant')
        self.assertEqual(df['Hotel Name'][2], 'Jade Fjord')
        self.assertEqual(df['Occupancy'][0], 2)
        self.assertEqual(df['Occupancy'][1], 2)
        self.assertEqual(df['Occupancy'][2], 2)
        df = self.reports.reportOccupancyByHotel(hotel='Elegant')
        self.assertEqual(len(df.index), 1)
        self.assertEqual(df['Hotel Name'][0], 'Elegant')
        self.assertEqual(df['Occupancy'][0], 2)

    ##
    ## Name: testReportOccupancyByRoomType
    ## Description:  Tests reportOccupancyByRoomType method on the Reports class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def testReportOccupancyByRoomType(self):
        df = self.reports.reportOccupancyByRoomType()
        self.assertEqual(len(df.index), 2)
        self.assertEqual(df['Room Type'][0], 'ECONOMY')
        self.assertEqual(df['Room Type'][1], 'PRESEDENTIAL_SUITE')
        self.assertEqual(df['Occupancy'][0], 4)
        self.assertEqual(df['Occupancy'][1], 2)
        df = self.reports.reportOccupancyByRoomType('ECONOMY')
        self.assertEqual(len(df.index), 1)
        self.assertEqual(df['Room Type'][0], 'ECONOMY')
        self.assertEqual(df['Occupancy'][0], 4)

    ##
    ## Name: testReportOccupancyByDateRange
    ## Description:  Tests reportOccupancyByDateRange method on the Reports class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def testReportOccupancyByDateRange(self):
        start = '2018-03-15'
        end = '2018-03-18'
        df = self.reports.reportOccupancyByDateRange(start, end)
        self.assertEqual(len(df.index), 6)
        self.assertEqual(df['Hotel Name'][0], 'Crimson Panorama')
        self.assertEqual(df['Hotel Name'][1], 'Elegant')
        self.assertEqual(df['Hotel Name'][2], 'Jade Fjord')
        self.assertEqual(df['Hotel Name'][3], 'Light Square')
        self.assertEqual(df['Hotel Name'][4], 'Northern River')
        self.assertEqual(df['Hotel Name'][5], 'Silver Vale')
        self.assertEqual(df['Occupancy'][0], 2)
        self.assertEqual(df['Occupancy'][1], 2)
        self.assertEqual(df['Occupancy'][2], 2)
        self.assertEqual(df['Occupancy'][3], 2)
        self.assertEqual(df['Occupancy'][4], 2)
        self.assertEqual(df['Occupancy'][5], 2)

        try:
            start = '2018-13-15'
            df = self.reports.reportOccupancyByDateRange(start, end)
            self.fail("Error: expected an exception")
        except Exception as e:
            self.assertEquals(str(e), "Error: invalid start date - {0}".format(start))

        try:
            start = '2018-03-44'
            df = self.reports.reportOccupancyByDateRange(start, end)
            self.fail("Error: expected an exception")
        except Exception as e:
            self.assertEquals(str(e), "Error: invalid start date - {0}".format(start))

        start = '2018-03-15'
        try:
            end = '2018-13-18'
            df = self.reports.reportOccupancyByDateRange(start, end)
            self.fail("Error: expected an exception")
        except Exception as e:
            self.assertEquals(str(e), "Error: invalid end date - {0}".format(end))

        try:
            end = '2018-03-44'
            df = self.reports.reportOccupancyByDateRange(start, end)
            self.fail("Error: expected an exception")
        except Exception as e:
            self.assertEquals(str(e), "Error: invalid end date - {0}".format(end))

    ##
    ## Name: testReportOccupancyByCity
    ## Description:  Tests reportOccupancyByCity method on the Reports class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def testReportOccupancyByCity(self):
        df = self.reports.reportOccupancyByCity()
        self.assertEqual(len(df.index), 3)
        self.assertEqual(df['City'][0], 'Capitol Heights')
        self.assertEqual(df['City'][1], 'Chicago')
        self.assertEqual(df['City'][2], 'New York')
        self.assertEqual(df['Occupancy'][0], 2)
        self.assertEqual(df['Occupancy'][1], 2)
        self.assertEqual(df['Occupancy'][2], 2)
        df = self.reports.reportOccupancyByCity(city='Chicago')
        self.assertEqual(len(df.index), 1)
        self.assertEqual(df['City'][0], 'Chicago')
        self.assertEqual(df['Occupancy'][0], 2)

    ##
    ## Name: testReportTotalOccupancy
    ## Description:  Tests reportTotalOccupancy method on the Reports class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def testReportTotalOccupancy(self):
        df = self.reports.reportTotalOccupancy()
        self.assertEqual(len(df.index), 1)
        self.assertEqual(df['Occupancy'][0], 6)

    ##
    ## Name: testReportTotalCapacity
    ## Description:  Tests reportTotalCapacity method on the Reports class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def testReportTotalCapacity(self):
        df = self.reports.reportTotalCapacity()
        self.assertEqual(len(df.index), 1)
        self.assertEqual(df['Capacity'][0], 20)

    ##
    ## Name: testReportStaffByRole
    ## Description:  Tests reportStaffByRole method on the Reports class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def testReportStaffByRole(self, role=None):
        df = self.reports.reportStaffByRole()
        self.assertEqual(len(df.index), 17)

        self.assertEqual(df['EmployeeID'][0], 1)
        self.assertEqual(df['EmployeeID'][1], 7)
        self.assertEqual(df['EmployeeID'][2], 9)

        self.assertEqual(df['Name'][3], 'Jack Harris')
        self.assertEqual(df['Name'][4], 'Albert Gray')
        self.assertEqual(df['Name'][5], 'Susan Howard')

        self.assertEqual(df['Age'][6], 20)
        self.assertEqual(df['Age'][7], 20)
        self.assertEqual(df['Age'][8], 45)

        self.assertEqual(df['JobTitle'][9], 'REPRESENTATIVE')
        self.assertEqual(df['JobTitle'][10], 'REPRESENTATIVE')
        self.assertEqual(df['JobTitle'][11], 'ROOM_SERVICE')

        self.assertEqual(df['Department'][12], 2)
        self.assertEqual(df['Department'][13], 3)
        self.assertEqual(df['Department'][14], 5)

        df = self.reports.reportStaffByRole(role='ROOM_SERVICE')
        self.assertEqual(len(df.index), 2)
        self.assertEqual(df['EmployeeID'][0], 4)
        self.assertEqual(df['EmployeeID'][1], 16)
        self.assertEqual(df['Name'][0], 'Guadalupe Greer')
        self.assertEqual(df['Name'][1], 'Paul Morris')
        self.assertEqual(df['Age'][1], 28)
        self.assertEqual(df['Age'][1], 28)
        self.assertEqual(df['JobTitle'][0], 'ROOM_SERVICE')
        self.assertEqual(df['JobTitle'][1], 'ROOM_SERVICE')
        self.assertEqual(df['Department'][0], 3)
        self.assertEqual(df['Department'][1], 2)

    ##
    ## Name: testReportStaffForCustomerByDate
    ## Description:  Tests reportStaffForCustomerByDate method on the Reports class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def testReportStaffForCustomerByDate(self):
        date = '2018-03-18'
        df = self.reports.reportStaffForCustomerByDate(date)
        self.assertEqual(len(df.index), 6)
        self.assertEqual(df['Name'][0], 'Carmen K House')
        self.assertEqual(df['Name'][1], 'Carmen K House')
        self.assertEqual(df['Check-In ID'][2], 1)
        self.assertEqual(df['Check-In ID'][3], 3)
        self.assertEqual(df['Service Name'][4], 'Dry Cleaning')
        self.assertEqual(df['Service Name'][5], 'Package Receiving')
        self.assertEqual(df['EmployeeID'][0], 6)
        self.assertEqual(df['EmployeeID'][1], 1)
        self.assertEqual(str(df['Date'][2]), '2018-03-18')
        self.assertEqual(str(df['Date'][3]), '2018-03-18')

        try:
            date = '2018-13-18'
            df = self.reports.reportStaffForCustomerByDate(date)
            self.fail("Error: expected an exception")
        except Exception as e:
            self.assertEquals(str(e), "Error: invalid date - {0}".format(date))

        try:
            date = '2018-03-33'
            df = self.reports.reportStaffForCustomerByDate(date)
            self.fail("Error: expected an exception")
        except Exception as e:
            self.assertEquals(str(e), "Error: invalid date - {0}".format(date))

        try:
            date = 'abc123'
            df = self.reports.reportStaffForCustomerByDate(date)
            self.fail("Error: expected an exception")
        except Exception as e:
            self.assertEquals(str(e), "Error: invalid date - {0}".format(date))

        date = '2018-03-18'
        name = 'Alexandra T Hoffman'
        df = self.reports.reportStaffForCustomerByDate(date, name=name)
        self.assertEqual(df['Name'][0], 'Alexandra T Hoffman')
        self.assertEqual(df['Check-In ID'][0], 3)
        self.assertEqual(df['Service Name'][0], 'Pet Sitting')
        self.assertEqual(df['EmployeeID'][0], 2)
        self.assertEqual(str(df['Date'][0]), '2018-03-18')

    ##
    ## Name: testReportStaffForCustomerByStay
    ## Description:  Tests reportStaffForCustomerByStay method on the Reports class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def testReportStaffForCustomerByStay(self):
        checkInId = 4
        df = self.reports.reportStaffForCustomerByStay(checkInId)
        self.assertEqual(len(df.index), 2)
        self.assertEqual(df['Name'][0], 'George J Driggers')
        self.assertEqual(df['Name'][1], 'George J Driggers')
        self.assertEqual(df['Check-In ID'][0], 4)
        self.assertEqual(df['Check-In ID'][1], 4)
        self.assertEqual(df['Service Name'][0], 'Package Receiving')
        self.assertEqual(df['Service Name'][1], 'Dry Cleaning')
        self.assertEqual(df['EmployeeID'][0], 3)
        self.assertEqual(df['EmployeeID'][1], 5)

        df = self.reports.reportStaffForCustomerByStay(700)
        self.assertEqual(len(df.index), 0)
        #print tabulate(df, headers=df.columns.values.tolist(), tablefmt='psql')

    ##
    ## Name: testReportRevenueByHotel
    ## Description:  Tests reportRevenueByHotel method on the Reports class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def testReportRevenueByHotel(self):
        start = '2018-03-15'
        end = '2018-03-18'
        df = self.reports.reportRevenueByHotel(start, end)
        self.assertEqual(len(df.index), 3)
        self.assertEqual(df['Hotel Name'][0], 'Light Square')
        self.assertEqual(df['Hotel Name'][1], 'Northern River')
        self.assertEqual(df['Hotel Name'][2], 'Silver Vale')
        self.assertEqual(df['Revenue'][0], 970.95)
        self.assertEqual(df['Revenue'][1], 1199.97)
        self.assertEqual(df['Revenue'][2], 469.96)

        df = self.reports.reportRevenueByHotel(start, end, hotel='Northern River')
        self.assertEqual(len(df.index), 1)
        self.assertEqual(df['Hotel Name'][0], 'Northern River')
        self.assertEqual(df['Revenue'][0], 1199.97)

if __name__ == '__main__':
    unittest.main()
