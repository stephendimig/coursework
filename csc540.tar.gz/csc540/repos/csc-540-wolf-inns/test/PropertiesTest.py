##########################################################
##
## File: PropertiesTest.py
## Author: Stephen Dimig (smdimig@ncsu.edu)
## Description: This file contains the test driver for the Properties
## class.
##
## The Properties class which is an API
## interface for properties retrieved from a json file. The Properties class
## is a Singleton which means there will be exactly one instance of it in the
## program. This will allow a user to change database connection information
## woithout modifying code.
##
##########################################################


import unittest
from Properties import Properties
import Utils
import os

##
## Class: PropertiesTest
## Description: The test driver for the Properties
##
class PropertiesTest(unittest.TestCase):
    ##
    ## Name: setUp
    ## Description:  The setUp fixture for the PropertiesTest class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def setUp(self):
        propertiesFile = os.environ.get('PROPERTIES_FILE')
        Properties.Instance().loadFile(propertiesFile)
        Utils.setUpLogging()

    ##
    ## Name: test
    ## Description: Basic sanity tests for the Properties class\.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def test(self):
        self.assertTrue(Properties.Instance().getDbHost() != None)
        self.assertTrue(Properties.Instance().getDbPassword() != None)
        self.assertTrue(Properties.Instance().getLogFile() != None)
        self.assertTrue(Properties.Instance().getDbName() != None)

if __name__ == '__main__':
    unittest.main()
