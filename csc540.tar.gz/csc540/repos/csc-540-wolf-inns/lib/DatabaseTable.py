##########################################################
##
## File: DatabaseTable.py
## Author: Stephen Dimig (smdimig@ncsu.edu)
## Description: This class is a base class for database access.
##
##########################################################

# Module Import #
import pymysql
import pandas as pd
import logging
from Properties import Properties


##
## Class: DatabaseTable
## Description: This class is a base class for MySql db connection and queries
##
class DatabaseTable(object):
    ##
    ## Name: __init__
    ## Description: Constructor for the DatabaseTable class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def __init__(self):
        self.logger = logging.getLogger()
        self.logger.debug(
            "IN - DatabaseTable constructor host=" + Properties.Instance().getDbHost() + "; user=" + Properties.Instance().getDbUser() + "; password=" + Properties.Instance().getDbPassword())

        self.conn = pymysql.connect(host=Properties.Instance().getDbHost(),
                                    user=Properties.Instance().getDbUser(),
                                    passwd=Properties.Instance().getDbPassword(),
                                    db=Properties.Instance().getDbName())
        self.cursorDict = self.conn.cursor(pymysql.cursors.DictCursor)
        self.cursor = self.conn.cursor()
        self.logger.debug("OUT - DatabaseTable constructor")

    def __del__(self):
        self.logger.debug("IN - DatabaseTable destructor")
        self.cursor.close()
        self.cursorDict.close()
        self.conn.close()
        self.logger.debug("OUT - DatabaseTable destructor")

    ##
    ## Name: resetConn
    ## Description: Reset the the MySql connection
    ##
    ## Parameters:
    ## None
    ##
    ## Returns: None
    ##
    def resetConn(self):
        self.logger.debug("IN - DatabaseTable resetConn")
        self.cursor.close()
        self.cursorDict.close()
        self.conn.close()
        self.conn = pymysql.connect(host=Properties.Instance().getDbHost(),
                                    user=Properties.Instance().getDbUser(),
                                    passwd=Properties.Instance().getDbPassword(),
                                    db=Properties.Instance().getDbName())
        self.cursorDict = self.conn.cursor(pymysql.cursors.DictCursor)
        self.cursor = self.conn.cursor()
        self.logger.debug("OUT - DatabaseTable resetConn")

    ##
    ## Name: getConn
    ## Description: Getter function that returns the MySql connector
    ##
    ## Parameters:
    ## None
    ##
    ## Returns: Return the MySql connector
    ##
    def getConn(self):
        return self.conn

    ##
    ## Name: getCursorDict
    ## Description: Getter function that returns the MySql cursor
    ## with values in a dictionary format
    ##
    ## Parameters: conn
    ##
    ## Returns: Return the MySql cursor in a dict format
    ##
    def getCursorDict(self):
        return self.cursorDict

    ##
    ## Name: getCursor
    ## Description: Getter function that returns the MySql cursor
    ##
    ## Parameters: conn
    ##
    ## Returns: Return the MySql cursor
    ##
    def getCursor(self):
        return self.cursor

    ##
    ## Name: commitConn
    ## Description: This function commits the db connection
    ##
    ## Parameters: conn
    ##
    ## Returns: none
    ##
    def commitConn(self):
        self.logger.debug("IN - DatabaseTable commitConn")
        self.conn.commit()
        self.logger.debug("OUT - DatabaseTable commitConn")

    ##
    ## Name: closeConn
    ## Description: This function closes the db connection
    ##
    ## Parameters: conn
    ##
    ## Returns: none
    ##
    def closeConn(self):
        self.logger.debug("IN - DatabaseTable closeConn")
        self.cursor.close()
        self.cursorDict.close()
        self.conn.close()
        self.logger.debug("OUT - DatabaseTable closeConn")

    ##
    ## Name: executeUpdate
    ## Description: This function runs the create query
    ##
    ## Parameters: query, type
    ##
    ## Returns: True if the query runs successfully, else False
    ##
    def executeUpdate(self, query):
        self.logger.debug("IN - DatabaseTable executeUpdate")
        retval = False
        try:
            self.cursor.execute(query)
            self.commitConn()
            self.logger.debug("executeUpdate completed")
            retval = True

        except Exception, e:
            print ("\nError executing SQL query: " + query + "\nError status:" + str(e))
            self.logger.exception("Error in executeUpdate. query=" + query)
            self.resetConn()
        self.logger.debug("OUT - DatabaseTable.executeUpdate. retval=" + str(retval))

    ##
    ## Name: updateDeleteQuery
    ## Description: This function runs the update/delete query
    ##
    ## Parameters: query, type
    ##
    ## Returns: True if the query runs successfully, else False
    ##
    def updateDeleteQuery(self, query, type):
        self.logger.debug("IN - DatabaseTable updateDeleteQuery")
        retval = False
        try:
            self.cursor.execute(query)
            self.commitConn()
            self.logger.debug("updateDeleteQuery completed")
            retval = True

        except Exception, e:
            print ("\nError executing SQL " + type + " query: " + query + "\nError status:" + str(e))
            self.logger.exception("Error executing updateDeleteQuery: " + query)
            self.resetConn()
        self.logger.debug("OUT - DatabaseTable updateDeleteQuery. retval=" + str(retval))


    ##
    ## Name: selectDfQuery
    ## Description: This function returns the select query
    ## result in a pandas dataframe format
    ##
    ## Parameters: query
    ##
    ## Returns: dataframe with select query result
    ##
    def selectDfQuery(self, query):
        self.logger.debug("IN - DatabaseTable selectDfQuery")
        self.logger.debug("connection : " + str(self.conn))
        df = None
        try:
            df = pd.read_sql(query, con=self.conn)
            self.logger.debug("Returned dataframe size" + str(len(df.index)))
            self.logger.debug("selectDfQuery completed")
        except Exception, e:
            df = pd.DataFrame()
            print ("\nError executing SQL INSERT query: " + query + "\nError status:" + str(e))
            self.resetConn()
            self.logger.exception("Error executing selectDfQuery")

        self.logger.debug("OUT - DatabaseTable selectDfQuery")
        return df

    ##
    ## Name: selectQuery
    ## Description: This function returns the select query
    ##
    ## Parameters: query
    ##
    ## Returns: select query result
    ##
    def selectQuery(self, query):
        self.logger.debug("IN - DatabaseTable selectQuery")
        result = []
        try:
            self.cursor.execute(query)
            result = self.cursor.fetchall()
            self.logger.debug("selectQuery completed")

        except Exception, e:
            print ("\nError executing SQL SELECT query: " + query + "\nError status:" + str(e))
            self.logger.exception("Error executing selectQuery: " + query)
            self.resetConn()

        self.logger.debug("OUT - DatabaseTable selectQuery")
        return result

    ##
    ## Name: insertQuery
    ## Description: This function inserts the query into db
    ##
    ## Parameters: query, params
    ##
    ## Returns: returns True if successful else false
    ##
    def insertQuery(self, query, params):
        self.logger.debug("IN - DatabaseTable insertQuery")
        retval = False
        try:
            self.cursor.execute(query, params)
            self.commitConn()
            self.logger.debug("insertQuery completed")

        except Exception, e:
            print ("\nError executing SQL INSERT query: " + query + "\nError status:" + str(e))
            self.logger.exception("Error executing insertQuery: " + query)
        self.logger.debug("OUT - DatabaseTable insertQuery. retval=" + str(retval))
        return retval

    ##
    ## Name: exists
    ## Description: This function returns true if the table exists, false otherwise
    ##
    ## Parameters:
    ## tablename - the name of the table
    ##
    ## Returns: returns True true if the table exists, false otherwise
    ##
    def __exists__(self, tablename):
        self.logger.debug("IN - DatabaseTable.exists")
        retval = False
        query = 'SHOW TABLES'
        self.logger.debug("Query" + query)
        df = self.selectDfQuery(query)
        self.logger.debug("Returned dataframe size" + str(len(df.index)))
        retval = tablename in df[df.columns.values[0]].tolist()
        self.logger.debug("OUT - DatabaseTable.exists: retval=" + str(retval))
        return retval

    ##
    ## Name: truncate
    ## Description: This function truncates the table
    ##
    ## Parameters:
    ## tablename - the name of the table
    ##
    ## Returns: returns True if successful else false
    ##
    def __truncate__(self, tablename):
        self.logger.debug("IN - DatabaseTable __truncate__")
        retval = False
        query = "truncate " + tablename
        try:
            self.cursor.execute(query)
            self.commitConn()
            self.logger.debug("truncate completed")

        except Exception, e:
            print ("\nError executing SQL TRUNCATE query: " + query + "\nError status:" + str(e))
            self.logger.exception("Error executing truncateQuery: " + query)

        self.logger.debug("OUT - DatabaseTable __truncate__. retval=" + str(retval))
        return retval
