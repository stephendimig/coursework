##########################################################
##
## File: Utils.py
## Author: Stephen Dimig (smdimig@ncsu.edu)
## Description: A collection of unrelated utility functions
##
##########################################################

import logging
from Properties import Properties

# This method setsup logging to the specified file for debug

##
## Name: setUpLogging
## Description: This method setsup logging to the specified file for debug
##
## Parameters:
## None
##
## Returns:
## None
##
def setUpLogging():
    logFile = Properties.Instance().getLogFile()
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    ch = logging.FileHandler(logFile)
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    root.addHandler(ch)