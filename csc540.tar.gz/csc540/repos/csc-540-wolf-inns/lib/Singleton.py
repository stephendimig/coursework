##########################################################
##
## File: Singleton.py
## Author: Stephen Dimig (smdimig@ncsu.edu)
## Description: A non-thread-safe helper class to ease implementing singletons.
## This should be used as a decorator -- not a metaclass -- to the
## class that should be a singleton.
##
## The decorated class can define one `__init__` function that
## takes only the `self` argument. Also, the decorated class cannot be
## inherited from. Other than that, there are no restrictions that apply
## to the decorated class.
##
## To get the singleton instance, use the `Instance` method. Trying
## to use `__call__` will result in a `TypeError` being raised.
##
##########################################################


##
## Class: Singleton
## Description: Non-thread safe implementation of the GOF Singlton
## pattern.
##
class Singleton:
    ##
    ## Name: __init__
    ## Description: Constructor for the Singleton class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def __init__(self, decorated):
        self._decorated = decorated

    ##
    ## Name: Instance
    ## Description: Returns the singleton instance. Upon its first call, it creates a
    ## new instance of the decorated class and calls its `__init__` method.
    ## On all subsequent calls, the already created instance is returned.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## The single instance of the singleton class is returned.
    ##
    def Instance(self):
        try:
            return self._instance
        except AttributeError:
            self._instance = self._decorated()
            return self._instance

    ##
    ## Name: __call__
    ## Description: Method I grabbed from Stack Overflow that will error
    ## out if a direct call to an object is attempted.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def __call__(self):
        raise TypeError('Singletons must be accessed through `Instance()`.')

    ##
    ## Name: __instancecheck__
    ## Description: Method I grabbed from Stack Overflow that will check to see
    ## if the instance is the correct type.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## True if inst is the same type of instance as _decorated.
    ##
    def __instancecheck__(self, inst):
        return isinstance(inst, self._decorated)
