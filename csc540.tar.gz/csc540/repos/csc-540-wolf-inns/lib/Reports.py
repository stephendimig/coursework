##########################################################
##
## File: Reports.py
## Author: Stephen Dimig (smdimig@ncsu.edu)
## Description: This class roughly corresponds to the Reports API described
## in the Project Report 1, with some further enahancements from the Reports section in
## the Interactive SQL queries section from Project Report 2. It has all of the queries
## described there in a class with appropriate error checks and tests.
##
##########################################################

import DatabaseTable
import logging
import re
import datetime

##
## Class: Reports
## Description: This is wrapper class for the set of queries described n
## the Interactive SQL queries section from Project Report 2. They are the
## type of queries that would be used by a manager.
##
class Reports(DatabaseTable.DatabaseTable):
    ##
    ## Name: __init__
    ## Description: Constructor for the Reports class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def __init__(self):
        self.logger = logging.getLogger()
        DatabaseTable.DatabaseTable.__init__(self)

    ##
    ## Name: reportOccupancyByHotel
    ## Description: Reports the total guests staying at each hotel
    ##
    ## Parameters:
    ## hotel - An optional parameter used to filter out only rows with the given Hotel Name.
    ##
    ## Returns:
    ## A pandas dataframe withthe following columns ['Hotel Name', 'Occupancy']
    ##
    def reportOccupancyByHotel(self, hotel=None):
        self.logger.debug("IN - Reports.reportOccupancyByHotel")
        query = "SELECT  Contact_Info.Name AS 'Hotel Name', SUM(Check_In.Num_Guests) AS 'Occupancy' \
        FROM Check_In, Hotel_Contact_Info, Contact_Info \
        WHERE Hotel_Contact_Info.Hotel_ID= Check_In.Hotel_ID AND Hotel_Contact_Info.Contact_Info_ID= Contact_Info.ID AND Check_In.Check_out_time IS NULL \
        GROUP BY Contact_Info.Name"
        df = self.selectDfQuery(query)
        if None != hotel:
            df = df[df['Hotel Name'] == hotel]
            df = df.reset_index()
            del df['index']
        self.logger.debug("OUT - Reports.reportOccupancyByHotel. query={0}".format(query))
        return df

    ##
    ## Name: reportOccupancyByRoomType
    ## Description: Reports the total guests staying in each type of room.
    ##
    ## Parameters:
    ## roomType - An optional parameter used to filter out only rows with the given type of room.
    ##
    ## Returns:
    ## A pandas dataframe withthe following columns ['Room Type', 'Occupancy']
    ##
    def reportOccupancyByRoomType(self, roomType=None):
        self.logger.debug("IN - Reports.reportOccupancyByRoomType")
        query = "SELECT  Room.Category AS 'Room Type', SUM(Check_In.Num_Guests) AS 'Occupancy' \
        FROM Room, Check_In \
        WHERE Room.Number=Check_In.Room_Number AND Check_In.Check_out_time IS NULL \
        GROUP BY Room.Category"
        df = self.selectDfQuery(query)
        if None != roomType:
            df = df[df['Room Type'] == roomType]
            df = df.reset_index()
            del df['index']

        self.logger.debug("OUT - Reports.reportOccupancyByRoomType. query={0}".format(query))
        return df

    ##
    ## Name: reportOccupancyByDateRange
    ## Description: Reports the total guests staying in each hotel during the time between the
    ## start and end dates.
    ##
    ## Parameters:
    ## start - The start date in yyyy-mm-dd format
    ## end - The end date in yyyy-mm-dd format
    ##
    ## Returns:
    ## A pandas dataframe withthe following columns ['Hotel Name', 'Occupancy']
    ##
    def reportOccupancyByDateRange(self, start, end):
        self.logger.debug("IN - Reports.reportOccupancyByDateRange. start={0}; end={1}" .format(start, end))

        match = re.match(r'([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})', start)
        if not match or int(match.group(2)) > 12 or int(match.group(2)) < 1 or int(match.group(3)) < 1 or int(match.group(3)) > 31:
            raise Exception("Error: invalid start date - {0}".format(start))

        match = re.match(r'([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})', end)
        if not match or int(match.group(2)) > 12 or int(match.group(2)) < 1 or int(match.group(3)) < 1 or int(match.group(3)) > 31:
            raise Exception("Error: invalid end date - {0}".format(end))

        query = "SELECT Contact_Info.Name AS 'Hotel Name', SUM(Check_In.Num_Guests) AS 'Occupancy' \
        FROM Check_In, Hotel_Contact_Info, Contact_Info \
        WHERE Hotel_Contact_Info.Hotel_ID= Check_In.Hotel_ID AND Hotel_Contact_Info.Contact_Info_ID= Contact_Info.ID AND \
        Check_In.Check_in_time >= '{0}' AND Check_In.Check_in_time <= '{1}' \
        GROUP BY Contact_Info.Name".format(start, end)
        df = self.selectDfQuery(query)
        self.logger.debug("OUT - Reports.reportOccupancyByDateRange. query={0}".format(query))
        return df

    ##
    ## Name: reportOccupancyByCity
    ## Description: Reports the total guests staying in each city.
    ##
    ## Parameters:
    ## city - An optional parameter that allows the report to be filtered by a city.
    ##
    ## Returns:
    ## A pandas dataframe withthe following columns ['City', 'Occupancy']
    ##
    def reportOccupancyByCity(self, city=None):
        self.logger.debug("IN - Reports.reportOccupancyByCity")
        query = "SELECT Contact_Info.City, SUM(Check_In.Num_Guests) AS 'Occupancy' \
        FROM Check_In, Hotel, Hotel_Contact_Info, Contact_Info \
        WHERE Check_In.Hotel_ID=Hotel.ID AND Hotel_Contact_Info.Hotel_ID=Hotel.ID AND Contact_Info.ID=Hotel_Contact_Info.Contact_Info_ID AND Check_In.Check_out_time IS NULL \
        GROUP BY Contact_Info.City"
        df = self.selectDfQuery(query)
        if None != city:
            df = df[df.City == city]
            df = df.reset_index()
            del df['index']
        self.logger.debug("OUT - Reports.reportOccupancyByCity. query={0}".format(query))
        return df

    ##
    ## Name: reportTotalOccupancy
    ## Description: Reports the total guests staying at all hotels.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## A pandas dataframe withthe following columns ['Occupancy']
    ##
    def reportTotalOccupancy(self):
        self.logger.debug("IN - Reports.reportTotalOccupancy")
        query = "SELECT SUM(Check_In.Num_Guests) AS 'Occupancy' \
        FROM Check_In \
        WHERE Check_In.Check_out_time IS NULL"
        df = self.selectDfQuery(query)
        self.logger.debug("OUT - Reports.reportTotalOccupancy. query={0}".format(query))
        return df

    ##
    ## Name: reportTotalCapacity
    ## Description: Reports the total room capacity staying at all hotels.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## A pandas dataframe withthe following columns ['Capacity']
    ##
    def reportTotalCapacity(self):
        self.logger.debug("IN - Reports.reportTotalCapacity")
        query = "SELECT SUM(Occupancy) AS 'Capacity' FROM Room"
        df = self.selectDfQuery(query)
        self.logger.debug("OUT - Reports.reportTotalCapacity. query={0}".format(query))
        return df

    ##
    ## Name: reportStaffByRole
    ## Description: Reports all of the staff members by their role.
    ##
    ## Parameters:
    ## role - An optional parameter that allows the dataframe to be filtered by a particular role.
    ##
    ## Returns:
    ## A pandas dataframe withthe following columns ['EmployeeID', 'Name', 'Age', 'JobTitle', 'Department']
    ##
    def reportStaffByRole(self, role=None):
        self.logger.debug("IN - Reports.reportStaffByRole")
        query = "SELECT Staff.EmployeeID, Contact_Info.Name AS    Name   , Age, JobTitle, Department \
        FROM Emp_Contact_Info, Contact_Info, Staff \
        WHERE Emp_Contact_Info.EmployeeID=Staff.EmployeeID AND Emp_Contact_Info.Contact_Info_ID= Contact_Info.ID \
        ORDER BY JobTitle, EmployeeID"
        df = self.selectDfQuery(query)

        if None != role:
            df = df[df['JobTitle'] == role]
            df = df.reset_index()
            del df['index']

        self.logger.debug("OUT - Reports.reportStaffByRole. query={0}".format(query))
        return df

    ##
    ## Name: reportStaffForCustomerByDate
    ## Description: Reports the staff members that served a guest on a given date.
    ##
    ## Parameters:
    ## date - The target date in yyyy-mm-dd format.
    ## name - An optional parameter that filters the dataframe on the name of the employee.
    ##
    ## Returns:
    ## A pandas dataframe withthe following columns ['Name', 'Check-In ID', 'Service Name', 'EmployeeID', 'Date']
    ##
    def reportStaffForCustomerByDate(self, date, name=None):
        self.logger.debug("IN - Reports.reportStaffForCustomerByDate. date={0}".format(date))

        match = re.match(r'([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})', date)
        if not match or int(match.group(2)) > 12 or int(match.group(2)) < 1 or int(match.group(3)) < 1 or int(
                match.group(3)) > 31:
            raise Exception("Error: invalid date - {0}".format(date))

        query = "SELECT Contact_Info.Name, Check_In.ID AS 'Check-In ID', Service.Name AS 'Service Name', Service_Log.EmployeeID, Service_Log.TimeStamp AS 'Date' \
        FROM Service_Log, Service, Customer_Contact_Info, Contact_Info, Check_In \
        WHERE Service_Log.Check_In_ID=Check_In.ID  AND Service.ID= Service_Log.ServiceID AND Customer_Contact_Info.Customer_Loyalty_Number=Check_In.Loyalty_Number AND Customer_Contact_Info.Contact_Info_ID=Contact_Info.ID \
        ORDER BY Check_In.ID"
        df = self.selectDfQuery(query)
        df.Name.replace({r'[^\x00-\x7F]+': ' '}, regex=True, inplace=True)
        target_date = datetime.datetime.strptime(date, '%Y-%m-%d').date()
        df['Date'] = df['Date'].dt.date
        df = df[df.Date == target_date]
        if None != name:
            df = df[df.Name == name]
        df = df.reset_index()
        del df['index']
        self.logger.debug("OUT - Reports.reportStaffForCustomerByDate. query={0}".format(query))
        return df

    ##
    ## Name: reportStaffForCustomerByStay
    ## Description: Reports the staff members that served a guest for a given stay.
    ##
    ## Parameters:
    ## checkInId - The check-in id for the target visit.
    ##
    ## Returns:
    ## A pandas dataframe withthe following columns ['Name', 'Check-In ID', 'Service Name', 'EmployeeID']
    ##
    def reportStaffForCustomerByStay(self, checkInId):
        self.logger.debug("IN - Reports.reportStaffForCustomerByStay")
        query = "SELECT Contact_Info.Name, Check_In.ID AS 'Check-In ID', Service.Name AS 'Service Name', Service_Log.EmployeeID \
        FROM Service_Log, Service, Customer_Contact_Info, Contact_Info, Check_In \
        WHERE Service_Log.Check_In_ID=Check_In.ID  AND Service.ID= Service_Log.ServiceID AND Customer_Contact_Info.Customer_Loyalty_Number= Check_In.Loyalty_Number AND Customer_Contact_Info.Contact_Info_ID= Contact_Info.ID \
        ORDER BY Check_In.ID"
        df = self.selectDfQuery(query)
        df.Name.replace({r'[^\x00-\x7F]+': ' '}, regex=True, inplace=True)
        df = df[df['Check-In ID'] == checkInId]
        df = df.reset_index()
        del df['index']
        self.logger.debug("OUT - Reports.reportStaffForCustomerByStay. query={0}".format(query))
        return df

    ##
    ## Name: RevenueByHotel
    ## Description: Reports the revenue by each hotel for a given date range.
    ##
    ## Parameters:
    ## start - The start date in yyyy-mm-dd format.
    ## end - The end date in yyyy-mm-dd format.
    ## hotel - An optional parameter that allows the dataframe to be filtered by the hotel name.
    ##
    ## Returns:
    ## A pandas dataframe withthe following columns ['Hotle Name', 'Revene']
    ##
    def reportRevenueByHotel(self, start, end, hotel=None):
        self.logger.debug("IN - Reports.reportRevenueByHotel")
        query = "SELECT Contact_Info.Name AS 'Hotel Name', SUM(Check_In.TotalCost) AS 'Revenue' \
        FROM Check_In, Hotel_Contact_Info, Contact_Info \
        WHERE Hotel_Contact_Info.Hotel_ID=Check_In.Hotel_ID AND Hotel_Contact_Info.Contact_Info_ID= Contact_Info.ID AND Check_In.Check_in_time >= '{0}' AND Check_In.Check_in_time <= '{1}' AND Check_In.TotalCost IS NOT NULL \
        GROUP BY Contact_Info.Name".format(start, end)
        df = self.selectDfQuery(query)
        if None != hotel:
            df = df[df['Hotel Name'] == hotel]
            df = df.reset_index()
            del df['index']
        self.logger.debug("OUT - Reports.reportRevunueByHotel. query={0}".format(query))
        return df


