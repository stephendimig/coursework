##########################################################
##
## File: InfoProcessing.py
## Author:
## Description: This class roughly corresponds to the InfoProcessing API described
## in the Project Report 1, with some further enahancements from the InfoProcessing section in
## the Interactive SQL queries section from Project Report 2. It has all of the queries
## described there in a class with appropriate error checks and tests.
##
##########################################################

import DatabaseTable
import logging
import pandas as pd

##
## Class: InfoProcessing
## Description: This is wrapper class for the set of queries described n
## the Interactive SQL queries section from Project Report 2. They are the
## type of queries that would be used by a front dest personel.
##
class InfoProcessing(DatabaseTable.DatabaseTable):
    ##
    ## Name: __init__
    ## Description: Constructor for the Reports class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def __init__(self):
        self.logger = logging.getLogger()
        DatabaseTable.DatabaseTable.__init__(self)

    ##
    ## Name: __getContactInfoId__
    ## Description: A private method that returns the Contact_Info_ID associated with a
    ## Customer_Loyalty_Number.
    ##
    ## Parameters:
    ## loyaltyNumber - The Customer Loyalty Number
    ##
    ## Returns:
    ## The Contact_Info_ID as an integer
    ##
    def __getContactInfoId__(self, loyaltyNumber):
        retval = None
        self.logger.debug("IN - __getContactInfoId__ : loyaltyNumber={0}".format(loyaltyNumber))
        query = 'SELECT Contact_Info_ID FROM Customer_Contact_Info WHERE Customer_Loyalty_Number={0}'.format(
            loyaltyNumber)
        df = self.selectDfQuery(query)
        if len(df.index) > 0:
            df = df.reset_index()
            retval = int(df['Contact_Info_ID'][0])
        self.logger.debug("OUT - __getContactInfoId__ : retval={0}".format(retval))
        return retval

    ##
    ## Name: createCustomerContact
    ## Description: This method creates a new customer contact info record.
    ##
    ## Parameters:
    ## loyaltyNumber - The customer loyalty number associated with the new contact
    ## name - The customer's name
    ## address - The customer's address
    ## city - The city of residence for the customer
    ## state - The state of residence for the customer
    ## zip - The zip code of the customer
    ## phone - The phone number for the customer
    ## email - An optional email address for the customer
    ##
    ## Returns:
    ## None
    ##
    def createCustomerContact(self, loyaltyNumber, name, address, city, state, zip, phone, email=None):
        self.logger.debug("IN - createCustomerContact : loyaltyNumber={0}, name={1}, address={2}, city={3}, state={4}, zip={5}, phone={6}, email={7}".
                          format(loyaltyNumber, name, address, city, state, zip, phone, email))
        query = "INSERT INTO Contact_Info(Name, Address, City, State, Zip, Phone_Number, Email) VALUES (%s, %s, %s, %s, %s, %s, %s)"
        params = (name, address, city, state, zip, phone, email)
        self.insertQuery(query, params)

        query = "INSERT INTO Customer_Contact_Info(Customer_Loyalty_Number, Contact_Info_ID) VALUES (%s, LAST_INSERT_ID())"
        params = (loyaltyNumber)
        self.insertQuery(query, params)
        self.logger.debug("OUT - createCustomerContact")
        return

    ##
    ## Name: updateCustomerContact
    ## Description: This method updates changed fields for a customer contact info record.
    ##
    ## Parameters:
    ## loyaltyNumber - The customer loyalty number associated with the new contact
    ## name - The customer's name
    ## address - The customer's address
    ## city - The city of residence for the customer
    ## state - The state of residence for the customer
    ## zip - The zip code of the customer
    ## phone - The phone number for the customer
    ## email - An optional email address for the customer
    ##
    ## Returns:
    ## None
    ##
    def updateCustomerContact(self, loyaltyNumber, name=None, address=None, city=None, state=None, zip=None, phone=None, email=None):
        self.logger.debug(
            "IN - updateCustomerContact")

        df = self.getCustomerContact(loyaltyNumber)
        contactInfoId = df['ID'][0]
        name = name if name != None else df['Name'][0]
        address = address if None != address else df['Address'][0]
        city = city if city != None else df['City'][0]
        state = state if state != None else df['State'][0]
        zip = zip if zip != None else df['Zip'][0]
        phone = phone if phone != None else df['Phone_Number'][0]
        email = email if email != None else df['Email'][0]
        query = "UPDATE Contact_Info SET Name='{0}', Address='{1}', City='{2}', State='{3}', Zip='{4}', Phone_Number='{5}', Email='{6}' WHERE ID={7}".\
            format(name, address, city, state, zip, phone, email, contactInfoId)
        self.updateDeleteQuery(query, type='UPDATE')
        self.logger.debug("OUT - updateCustomerContact. query={0}".format(query))
        return

    ##
    ## Name: deleteCustomerContact
    ## Description: This method deletes a customer contact
    ##
    ## Parameters:
    ## loyaltyNumber - The customer loyalty number associated with the new contact
    ##
    ## Returns:
    ## None
    ##
    def deleteCustomerContact(self, loyaltyNumber):
        self.logger.debug("IN - deleteCustomerContact : loyaltyNumber={0}".format(loyaltyNumber))
        contactInfoId = self.__getContactInfoId__(loyaltyNumber)
        if None != contactInfoId:
            query = 'DELETE FROM Customer_Contact_Info WHERE Customer_Loyalty_Number={0}'.format(loyaltyNumber)
            self.updateDeleteQuery(query=query, type='DELETE')
            query = 'DELETE FROM Contact_Info WHERE ID={0}'.format(contactInfoId)
            self.updateDeleteQuery(query=query, type='DELETE')
        self.logger.debug("OUT - deleteCustomerContact")

    ##
    ## Name: getCustomerContact
    ## Description: This method retrieves a customer contact
    ##
    ## Parameters:
    ## loyaltyNumber - The customer loyalty number associated with the new contact
    ##
    ## Returns:
    ## A dataframe with the following columns ['ID', 'Name', 'Address', 'City', 'State', 'Zip', 'Phone_Number', 'Email']
    ##
    def getCustomerContact(self, loyaltyNumber):
        self.logger.debug("IN - getCustomerContact : loyaltyNumber={0}".format(loyaltyNumber))
        contactInfoId = self.__getContactInfoId__(loyaltyNumber)
        df = pd.DataFrame()
        query = ""
        if None != contactInfoId:
            query = 'SELECT * FROM Contact_Info WHERE ID={0}'.format(contactInfoId)
            df = self.selectDfQuery(query)
            df.Name.replace({r'[^\x00-\x7F]+':' '}, regex=True, inplace=True)
        self.logger.debug("OUT - getCustomerContact : query=" + query + str(df))
        return df

    ##
    ## Name: getAllCustomerContact
    ## Description: This method retrieves all of the customer contacts
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## A dataframe with the following columns ['ID', 'Name', 'Address', 'City', 'State', 'Zip', 'Phone_Number', 'Email']
    ##
    def getAllCustomerContact(self):
        self.logger.debug("IN - getAllCustomerContact")
        query = 'SELECT * FROM Contact_Info'

        df = self.selectDfQuery(query)
        df.Name.replace({r'[^\x00-\x7F]+':' '}, regex=True, inplace=True)
        self.logger.debug("OUT - getAllCustomerContact : query=" + query + str(df))
        return df

