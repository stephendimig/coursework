##########################################################
##
## File: BillingRecords.py
## Author: Stephen Dimig (smdimig@ncsu.edu)
## Description: This class roughly corresponds to the Billing Records API described
## in the Project Report 1, with some further enahancements from the Maintaining billing
## accounts section in the Interactive SQL queries section from Project Report 2. It has
## all of the queries described there in a class with appropriate error checks and tests.
##
##########################################################

import DatabaseTable
import logging

##
## Class: BillingRecords
## Description: This is wrapper class for the set of queries described in
## the Maintaining billing accounts sub-section in the Interactive SQL queries
## section from Project Report 2. They are the type of queries that would be
## used by a front desk clerk.
##
class BillingRecords(DatabaseTable.DatabaseTable):

    ##
    ## Name: __init__
    ## Description: Constructor for the BillingRecords class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def __init__(self):
        self.logger = logging.getLogger()
        DatabaseTable.DatabaseTable.__init__(self)

    def start(self, num_Guests, hotelId, roomNumber, loyaltyNumber):
        pass

    def listServicesUsed(self):
        pass

    def getCostOfServices(self, checkInId):
        pass

    def listRoomRates(self):
        pass

    def getRoomRate(self, checkInId):
        pass

    def listDurationOfStays(self):
        pass

    def getDurationOfStay(self, checkInId):
        pass

    def generateFinalBill(self, checkInId):
        pass






