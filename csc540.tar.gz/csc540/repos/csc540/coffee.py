# Module Import #
from Properties import Properties
import DatabaseTable
from tabulate import tabulate
import logging
import os

# Class to implemant Coffee.java example
class Coffees(DatabaseTable.DatabaseTable):
    TABLE_NAME = "COFFEES"

    #Constructor
    def __init__(self):
        self.logger = logging.getLogger()
        self.logger.debug("IN - Coffees constructor")
        DataBaseDriver.DataBaseDriver.__init__(self)
        self.logger.debug("OUT - Coffees constructor")

    # This implements the create table for the COFFEE table
    def create(self):
        self.executeUpdate('CREATE TABLE ' + self.TABLE_NAME + ' (COF_NAME VARCHAR(32), SUP_ID INTEGER, '
                           + 'PRICE FLOAT, SALES INTEGER, TOTAL INTEGER)')

    # Insert a row into the COFFEE table
    def insert(self, name, supId, price, sales, total):
        self.logger.debug("IN - Coffees.insert")
        query = 'INSERT INTO ' + self.TABLE_NAME + ' ( COF_NAME, SUP_ID, PRICE, SALES, TOTAL) '+ \
                'VALUES(% s, % s, % s, % s, % s)'
        self.logger.debug("Query: " + query)
        params = (name, supId, price, sales, total)
        self.logger.debug("OUT - Coffees.insert")
        return self.insertQuery(query, params)

    # Get all rows from the COFFEE table returned as a dataframe
    def getAll(self, order_by='COF_NAME'):
        self.logger.debug("IN - Coffees.get")
        query = 'SELECT * FROM ' + self.TABLE_NAME + ' ORDER BY ' + order_by
        self.logger.debug("Query" + query)
        df = self.selectDfQuery(query)
        self.logger.debug("Returned dataframe size" + str(len(df.index)))
        self.logger.debug("OUT - Coffees.get")
        return df


# This method setsup logging to the specified file for debug
def setUpLogging():
    logFile = Properties.Instance().getLogFile()
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    ch = logging.FileHandler(logFile)
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    root.addHandler(ch)

# Load the properties file that controls things like your database host, username, and password.
Properties.Instance().loadFile('/Users/sdimig/csc540/repos/properties.json')

# Set up logging for
setUpLogging()

# Make an instance of Coffees
coffees = Coffees()

# Create the table
coffees.create()

# Insert into the table
coffees.insert('Colombian', 101, 7.99, 0, 0)
coffees.insert('French_Roast', 49, 8.99, 0, 0)
coffees.insert('Espresso', 150, 9.99, 0, 0)
coffees.insert('Colombian_Decaf', 101, 8.99, 0, 0)
coffees.insert('French_Roast_Decaf', 49, 9.99, 0, 0)

# Get all instances of the table
df = coffees.getAll()
print tabulate(df, headers=df.columns.values.tolist(), tablefmt='psql')
