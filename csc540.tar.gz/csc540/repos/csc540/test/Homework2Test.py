import unittest
from Homework2 import Students
from Homework2 import Schools
from Properties import Properties

class Homework2Test(unittest.TestCase):
    def setUp(self):
        Properties.Instance().loadFile('/Users/sdimig/csc540/repos/properties.json')
        self.students = Students()
        self.schools = Students()

    def testExists(self):
        self.assertEqual(self.students.exists(), True)
        self.assertEqual(self.schools.exists(), True)



if __name__ == '__main__':
    unittest.main()
