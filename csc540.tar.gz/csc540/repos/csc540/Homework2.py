# Module Import #
from Properties import Properties
import DatabaseTable
from tabulate import tabulate
import logging


# Class to implement Students table
class Students(DatabaseTable.DatabaseTable):
    TABLE_NAME = "Students"

    # Constructor
    def __init__(self):
        self.logger = logging.getLogger()
        self.logger.debug("IN - Students constructor")
        DatabaseTable.DatabaseTable.__init__(self)
        self.logger.debug("OUT - Students constructor")

    # This implements the create table for the Students table
    def create(self):
        self.executeUpdate('CREATE TABLE ' + self.TABLE_NAME + ' (Name VARCHAR(20), ' +
                           'School VARCHAR(10), Age INTEGER, FundingReceived INTEGER, Income INTEGER, Sex CHAR(1))')

    # Insert a row into the Students table
    def insert(self, name, school, age, fundingReceived, income, sex):
        self.logger.debug("IN - Students.insert. name=" + name + "; age=" + str(age) + "; fundingReceived=" +
                          str(fundingReceived) + "; income=" + str(income) + "; sex=" + str(sex))
        query = 'INSERT INTO ' + self.TABLE_NAME + ' ( Name, School, Age, FundingReceived, Income, Sex) ' + \
                'VALUES(% s, % s, % s, % s, % s, % s)'
        self.logger.debug("Query: " + query)
        params = (name, school, age, fundingReceived, income, sex)
        self.logger.debug("OUT - Students.insert")
        return self.insertQuery(query, params)

    def exists(self):
        return DatabaseTable.DatabaseTable.__exists__(self, self.TABLE_NAME)

    def truncate(self):
        return DatabaseTable.DatabaseTable.__truncate__(self, self.TABLE_NAME)

# Class to implement Students table
class Schools(DatabaseTable.DatabaseTable):
    TABLE_NAME = "Schools"

    # Constructor
    def __init__(self):
        self.logger = logging.getLogger()
        self.logger.debug("IN - Schools constructor")
        DatabaseTable.DatabaseTable.__init__(self)
        self.logger.debug("OUT - Schools constructor")

    # This implements the create table for the Schools table
    def create(self):
        self.executeUpdate('CREATE TABLE ' + self.TABLE_NAME + ' (Name VARCHAR(10), Location VARCHAR(30), ' +
                           'TuitionFees INTEGER, LivingExpenses INTEGER)')

    # Insert a row into the Schools table
    def insert(self, name, location, tuitionFees, livingExpenses):
        self.logger.debug("IN - Schools.insert. name=" + name + "; location=" + location + "; tuitionFees=" +
                          str(tuitionFees) + "; livingExpenses=" + str(livingExpenses))
        query = 'INSERT INTO ' + self.TABLE_NAME + ' ( Name, Location, TuitionFees, LivingExpenses) ' + \
                'VALUES(% s, % s, % s, % s)'
        self.logger.debug("Query: " + query)
        params = (name, location, tuitionFees, livingExpenses)
        self.logger.debug("OUT - Schools.insert")
        return self.insertQuery(query, params)

    def exists(self):
        return DatabaseTable.DatabaseTable.__exists__(self, self.TABLE_NAME)

    def truncate(self):
        return DatabaseTable.DatabaseTable.__truncate__(self, self.TABLE_NAME)

class SchoolsAndStudents(DatabaseTable.DatabaseTable):
    # Constructor
    def __init__(self, schools, students):
        self.logger = logging.getLogger()
        self.logger.debug("IN - SchoolsAndStudents constructor")
        DatabaseTable.DatabaseTable.__init__(self)
        self.schools = schools
        self.students = students
        self.logger.debug("OUT - SchoolsAndStudents constructor")

    def checkAbilityToStudy(self, studentName):
        retval = False
        self.logger.debug("IN - SchoolsAndStudents.checkAbilityToStudy: studentName=" + studentName)
        query = "SELECT (FundingReceived+Income) AS TotalIncome, (TuitionFees+LivingExpenses) AS " + \
                "TotalFees FROM " + self.students.TABLE_NAME + ", " + self.schools.TABLE_NAME + " WHERE Students.School = Schools.Name AND Students.Name " + \
                "LIKE '" + studentName + "%'"
        self.logger.debug("Query" + query)
        result = self.selectDfQuery(query)
        self.logger.debug("Returned dataframe size" + str(len(result.index)))

        retval = int(result["TotalIncome"][0]) > int(result["TotalFees"][0])
        self.logger.debug("OUT - SchoolsAndStudents.checkAbilityToStudy: retval=" + str(retval))
        return retval

    # statement.executeUpdate("UPDATE Schools SET TuitionFees = 30000 WHERE Name = 'NYU'");
    def updateTuitionFees(self, tuitionFees, pattern):
        self.logger.info("IN - SchoolsAndStudents.updateTuitionFees: tuitionFees=" + str(tuitionFees))
        query = "UPDATE Schools SET TuitionFees=" + str(tuitionFees) + " WHERE Name LIKE '" + pattern + "'"
        self.logger.info("Query" + query)
        self.logger.info("OUT - SchoolsAndStudents.updateTuitionFees")
        self.cursor.execute(query)

    # statement.executeUpdate("UPDATE Students SET Income = 39000 WHERE Name LIKE 'Angela%'");
    def updateIncome(self, income, pattern):
        self.logger.info("IN - SchoolsAndStudents.updateIncome: income=" + str(income))
        query = "UPDATE Students SET Income=" + str(income) + " WHERE Name LIKE '" + pattern + "'"
        self.logger.info("Query" + query)
        self.logger.info("OUT - SchoolsAndStudents.updateIncome")
        self.cursor.execute(query)

    # Modified version of modifyALittleBit2 where:
    # either both execute correctly together (this is the "Success" case in the code),
    # or not execute at all (the "Failure" case).
    def modifyALittleBit2(self):
        self.logger.info("IN - SchoolsAndStudents.modifyALittleBit2")
        try:
            # either both execute correctly together (this is the "Success" case in the code),
            # in which case no exception is thrown
            self.updateIncome(50000, 'Angela%')
            self.updateTuitionFees(15000, 'NYU')
            self.commitConn()
        except Exception, e:
            # or not execute at all (the "Failure" case). Exception is caught and transaction is
            # rolled back.
            self.logger.exception("Error executing modifyALittleBit2. e=" + str(e))
            self.connection.rollback()
        self.logger.info("OUT - SchoolsAndStudents.modifyALittleBit2")

    def modifyALittleBit1(self):
        self.logger.info("IN - SchoolsAndStudents.modifyALittleBit1")
        self.updateIncome(39000, 'Angela%')
        self.updateTuitionFees(30000, 'NYU')
        self.logger.info("OUT - SchoolsAndStudents.modifyALittleBit1")

# This method setsup logging to the specified file for debug
def setUpLogging():
    logFile = Properties.Instance().getLogFile()
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    ch = logging.FileHandler(logFile)
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    root.addHandler(ch)

def initialize(schools, students):
    if not students.exists():
        students.create()
    students.insert('Todd', 'NC State', 18, 16000, 30000, 'M')
    students.insert('Max', 'Stanford', 21, 20000, 70000, 'M')
    students.insert('Alex', 'UNC', 19, 8000, 40000, 'M')
    students.insert('Natasha', 'Harvard', 22, 15000, 75000, 'F')
    students.insert('Kelly', 'UCLA', 23, 2000, 50000, 'F')
    students.insert('Angela', 'NYU', 18, 8000, 45000, 'F')
    if not schools.exists():
        schools.create()
    schools.insert('NC State', 'North Carolina', 24000, 20000)
    schools.insert('Stanford', 'California', 44000, 35000)
    schools.insert('UNC', 'North Carolina', 34000, 20000)
    schools.insert('Harvard', 'Massachusetts', 50000, 38000)
    schools.insert('UCLA', 'California', 36000, 30000)
    schools.insert('NYU', 'New York', 22000, 41000)

if __name__ == '__main__':
    # Load the properties file that controls things like your database host, username, and password.
    Properties.Instance().loadFile('/Users/sdimig/csc540/repos/properties.json')

    # Set up logging for
    setUpLogging()

    students = Students()
    schools = Schools()
    schoolsAndStudents = SchoolsAndStudents(schools, students)
    schools.truncate()
    students.truncate()

    initialize(schools, students)
    canAfford1 = schoolsAndStudents.checkAbilityToStudy("Todd")

    #schoolsAndStudents.modifyALittleBit1()
    schoolsAndStudents.modifyALittleBit2()
    canAfford2 = schoolsAndStudents.checkAbilityToStudy("Angela")

    if canAfford1 == canAfford2:
        print "Success"
    else:
        print "Failure"
