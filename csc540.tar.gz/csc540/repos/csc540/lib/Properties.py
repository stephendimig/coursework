##########################################################
##
## File: Properties.py
## Author: Stephen Dimig (sdimig@netapp.com)
## Description: This file contains the Properties class which is an API
## interface for properties retrieved from a json file. The Properties class
## is a Singleton which means there will be exactly one instance of it in the
## program. This will allow a user to change database connection information
## woithout modifying code.
##
##########################################################

from Singleton import Singleton
import pandas as pd


##
## Class: Properties
## Description: This is a singleton class that provides an access api to
## the properties file. Note the use of python pandas to read in the json file
## and provide easy access to the key-value pairs.
##
@Singleton
class Properties:
    ##
    ## Name: __init__
    ## Description: Constructor for the Properties class.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## None
    ##
    def __init__(self):
        self.df = None

    ##
    ## Name: loadFile
    ## Description: This method is used to load a json formatted configuration
    ## file.
    ##
    ## Parameters:
    ## filename - The name of the json formatted configuration file.
    ##
    ## Returns:
    ## A dataframe with all key-value pairs in it is returned.
    ##
    def loadFile(self, filename):
        self.df = pd.read_json(filename)
        return self.df

    ##
    ## Name: getDbHost
    ## Description: This method will return the database hostname.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## The database hostname is returned, or none if that key does
    ## not exist.
    ##
    def getDbHost(self):
        retval = None
        mydf = self.df[self.df.key == 'DB_HOST']
        if len(mydf) >= 1:
            mydf = mydf.reset_index()
            retval = mydf['value'].iloc[0]
        return retval

    ##
    ## Name: getDbUser
    ## Description: This method will return the database user.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## The database user is returned, or none if that key does
    ## not exist.
    ##
    def getDbUser(self):
        retval = None
        mydf = self.df[self.df.key == 'DB_USER']
        if len(mydf) >= 1:
            mydf = mydf.reset_index()
            retval = mydf['value'].iloc[0]
        return retval

    ##
    ## Name: getDbName
    ## Description: This method will return the name of database used.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## The name of the database is returned, or none if that key does
    ## not exist.
    ##
    def getDbName(self):
        retval = None
        mydf = self.df[self.df.key == 'DB_NAME']
        if len(mydf) >= 1:
            mydf = mydf.reset_index()
            retval = mydf['value'].iloc[0]
        return retval

    ##
    ## Name: getDbPassword
    ## Description: This method will return the database password.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## The database password is returned, or none if that key does
    ## not exist.
    ##
    def getDbPassword(self):
        retval = None
        mydf = self.df[self.df.key == 'DB_PASSWORD']
        if len(mydf) >= 1:
            mydf = mydf.reset_index()
            retval = mydf['value'].iloc[0]
        return retval

    ##
    ## Name: getLogFile
    ## Description: This method will return the path to the logfile.
    ##
    ## Parameters:
    ## None
    ##
    ## Returns:
    ## The path to the logfile is returned, or none if that key does
    ## not exist.
    ##
    def getLogFile(self):
        retval = None
        mydf = self.df[self.df.key == 'LOG_FILE']
        if len(mydf) >= 1:
            mydf = mydf.reset_index()
            retval = mydf['value'].iloc[0]
        return retval
