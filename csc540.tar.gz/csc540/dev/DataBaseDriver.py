##########################################################
##
## File: DataBaseDriver.py
## Author: Priysha Pradhan (priysha@netapp.com)
## Description: This class is a base class to setup DB connection and run MySql db queries
## for WatchDog governance
##
##########################################################

# Module Import #
import pymysql
import pandas as pd
from pandas.io import sql
import logging
from HclProperties import HclProperties

##
## Class: DataBaseDriver
## Description: This class is a base class for MySql db connection and queries
##
class DataBaseDriver(object):

    def __init__(self):
        self.logger = logging.getLogger('HCL')
        self.logger.debug("IN - DataBaseDriver constructor")
        self.conn = pymysql.connect(host=HclProperties.Instance().getDbHost(),
                                    user=HclProperties.Instance().getDbUser(),
                                    passwd=HclProperties.Instance().getDbPassword(),
                                    db=HclProperties.Instance().getDbName())
        self.cursorDict = self.conn.cursor(pymysql.cursors.DictCursor)
        self.cursor = self.conn.cursor()
        self.logger.debug("OUT - DataBaseDriver constructor")

    def __del__(self):
        self.logger.debug("IN - DataBaseDriver destructor")
        self.cursor.close()
        self.cursorDict.close()
        self.conn.close()

    ##
    ## Name: resetConn
    ## Description: Reset the the MySql connection
    ##
    ## Parameters:
    ## None
    ##
    ## Returns: None
    ##
    def resetConn(self):
        self.logger.debug("IN - DataBaseDriver reset")
        self.cursor.close()
        self.cursorDict.close()
        self.conn.close()
        self.conn = pymysql.connect(host=HclProperties.Instance().getDbHost(),
                                    user=HclProperties.Instance().getDbUser(),
                                    passwd=HclProperties.Instance().getDbPassword(),
                                    db=HclProperties.Instance().getDbName())
        self.cursorDict = self.conn.cursor(pymysql.cursors.DictCursor)
        self.cursor = self.conn.cursor()
        self.logger.debug("OUT - DataBaseDriver reset")

    ##
    ## Name: getConn
    ## Description: Getter function that returns the MySql connector
    ##
    ## Parameters:
    ## None
    ##
    ## Returns: Return the MySql connector
    ##
    def getConn(self):
        self.logger.debug("IN - DataBaseDriver getConn")
        return self.conn


    ##
    ## Name: getCursorDict
    ## Description: Getter function that returns the MySql cursor
    ## with values in a dictionary format
    ##
    ## Parameters: conn
    ##
    ## Returns: Return the MySql cursor in a dict format
    ##
    def getCursorDict(self):
        self.logger.debug("IN - DataBaseDriver getCursorDict")
        return self.cursorDict


    ##
    ## Name: getCursor
    ## Description: Getter function that returns the MySql cursor
    ##
    ## Parameters: conn
    ##
    ## Returns: Return the MySql cursor
    ##
    def getCursor(self):
        self.logger.debug("IN - DataBaseDriver getCursor")
        return self.cursor

    ##
    ## Name: commitConn
    ## Description: This function commits the db connection
    ##
    ## Parameters: conn
    ##
    ## Returns: none
    ##
    def commitConn(self):
        self.logger.debug("IN - DataBaseDriver commitConn")
        self.conn.commit()
        self.logger.debug("OUT - DataBaseDriver commitConn")

    ##
    ## Name: closeConn
    ## Description: This function closes the db connection
    ##
    ## Parameters: conn
    ##
    ## Returns: none
    ##
    def closeConn(self):
        self.logger.debug("IN - DataBaseDriver closeConn")
        self.cursor.close()
        self.cursorDict.close()
        self.conn.close()
        self.logger.debug("OUT - DataBaseDriver closeConn")

    ##
    ## Name: updateDeleteQuery
    ## Description: This function runs the update/delete query
    ##
    ## Parameters: query, type
    ##
    ## Returns: True if the query runs successfully, else False
    ##
    def updateDeleteQuery(self, query, type):
        self.logger.debug("IN - DataBaseDriver updateDeleteQuery")
        try:
            self.cursor.execute(query)
            self.commitConn()
            self.logger.debug("updateDeleteQuery completed")
            return True

        except Exception, e:
            print ("\nError executing SQL " + type + " query: " + query + "\nError status:" + str(e))
            self.logger.exception("Error executing updateDeleteQuery: " + query)
            self.resetConn()
            return False


    ##
    ## Name: selectDfQuery
    ## Description: This function returns the select query
    ## result in a pandas dataframe format
    ##
    ## Parameters: query
    ##
    ## Returns: dataframe with select query result
    ##
    def selectDfQuery(self, query):
        self.logger.debug("IN - DataBaseDriver selectDfQuery")
        self.logger.debug("connection : " + str(self.conn))

        try:
            df = pd.read_sql(query, con=self.conn)
            self.logger.debug("Returned dataframe size" + str(len(df.index)))
            self.logger.debug("selectDfQuery completed")
            return df
        except Exception, e:
            df = pd.DataFrame()
            print ("\nError executing SQL INSERT query: " + query + "\nError status:" + str(e))
            self.resetConn()
            self.logger.exception("Error executing selectDfQuery")
            return df

    ##
    ## Name: selectQuery
    ## Description: This function returns the select query
    ##
    ## Parameters: query
    ##
    ## Returns: select query result
    ##
    def selectQuery(self, query):
        self.logger.debug("IN - DataBaseDriver selectQuery")
        result = []
        try:
            self.cursor.execute(query)
            result = self.cursor.fetchall()
            self.logger.debug("selectQuery completed")

        except Exception, e:
            print ("\nError executing SQL SELECT query: " + query + "\nError status:" + str(e))
            self.logger.exception("Error executing selectQuery: " + query)
            self.resetConn()
        return result

    ##
    ## Name: insertQuery
    ## Description: This function inserts the query into db
    ##
    ## Parameters: query, params
    ##
    ## Returns: returns True if successful else false
    ##
    def insertQuery(self,query, params):
        self.logger.debug("IN - DataBaseDriver insertQuery")
        try:
            self.cursor.execute(query, params)
            self.commitConn()
            self.logger.debug("insertQuery completed")
            return True

        except Exception, e:
            print ("\nError executing SQL INSERT query: " + query + "\nError status:" + str(e))
            self.logger.exception("Error executing insertQuery: " + query)
            return False



    ##
    ## Name: truncate
    ## Description: This function truncates the table
    ##
    ## Parameters:
    ## tablename - the name of the table
    ##
    ## Returns: returns True if successful else false
    ##
    def __truncate__(self, tablename):
        self.logger.debug("IN - DataBaseDriver truncate")
        query = "truncate " + tablename
        try:
            self.cursor.execute(query)
            self.commitConn()
            self.logger.debug("truncate completed")
            return True

        except Exception, e:
            print ("\nError executing SQL TRUNCATE query: " + query + "\nError status:" + str(e))
            self.logger.exception("Error executing truncateQuery: " + query)
            return False



