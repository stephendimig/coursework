# Module Import #
import pymysql
import pandas as pd
from pandas.io import sql
from tabulate import tabulate

conn = pymysql.connect(host='classdb2.csc.ncsu.edu',
                       user='smdimig',
                       passwd='%Anniegirl1%',
                       db='smdimig')

query = "SELECT * FROM emp"
df = pd.read_sql(query, con=conn)

print tabulate(df, headers=df.columns.values.tolist(), tablefmt='psql')
