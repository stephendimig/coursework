# Module Import #
import pymysql
import pandas as pd
from pandas.io import sql
from tabulate import tabulate

conn = pymysql.connect(host='127.0.0.1',
                       user='root',
                       passwd='netapp1!',
                       db='test')

query = "SELECT * FROM COFFEES"
df = pd.read_sql(query, con=conn)

print tabulate(df, headers=df.columns.values.tolist(), tablefmt='psql')
