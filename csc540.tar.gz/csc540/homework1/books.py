# Module Import #
import pymysql
import pandas as pd
from pandas.io import sql
from tabulate import tabulate

conn = pymysql.connect(host='127.0.0.1',
                       user='root',
                       passwd='netapp1!',
                       db='test_python')

query = "SELECT * FROM BOOKS where price > 9.00"
df = pd.read_sql(query, con=conn)
print tabulate(df, headers=df.columns.values.tolist(), tablefmt='psql')

query = "SELECT * FROM BOOKS where price <= 9.00"
df = pd.read_sql(query, con=conn)
print tabulate(df, headers=df.columns.values.tolist(), tablefmt='psql')

query = "SELECT * FROM BOOKS where BOOK_TITLE='Queen Lucia'"
df = pd.read_sql(query, con=conn)
print tabulate(df, headers=df.columns.values.tolist(), tablefmt='psql')
