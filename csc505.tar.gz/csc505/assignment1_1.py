#!/usr/bin/python

import math

def MYSTERY(n):
    sum = 1
    count = 0
    for i in range(1, n + 1):
        # 2 ** (n * (n-1))
        if i < 6: 
            for k in range(1, n + 1):
                sum = sum * 2
                count = count + 1
        else:
            # 5 ** (n - 5) * (2 ** (n * 5))
            if i < 10:
                sum = sum * 5
                count = count + 1
            # 3 ** (n - 9) * (5 ** 4 * (2 ** (n * 5)))
            else:
                sum = sum * 3
                count = count + 1
    return sum, count

def PREDICT(n):
    if n < 6:
        return 2 ** (n * n)
    elif n < 10:
        return 5 ** (n - 5) * (2 ** (n * 5))
    else:
        return 3 ** (n - 9) * (5 ** 4 * (2 ** (n * 5)))

if __name__ == "__main__":
    for i in range(1, 15):
        result, count = MYSTERY(i)
        print result, PREDICT(i), i, count 
