#!/usr/bin/python

def BUBBLESORT(A):
    print A
    for i in range(0, len(A)):
        for j in range(len(A) - 1, i, -1):
            if A[j] < A[j - 1]:
                temp = A[j]
                A[j] = A[j - 1]
                A[j - 1] = temp
        print A
    return A

if __name__ == "__main__":
    A = [5, 2, 4, 6, 1, 3]
    print BUBBLESORT(A)
